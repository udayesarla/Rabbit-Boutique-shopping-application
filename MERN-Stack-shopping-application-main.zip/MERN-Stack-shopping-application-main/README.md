# MERN-Stack-shopping-application
### kindly install required packages in both front-end(client folder) and back-end as well using (npm i) before starting the server
### then try running the server using 'npm run dev' command
